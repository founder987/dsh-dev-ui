/**
 * client 半：R9 当前提问浮层（C7-1）。
 * 渲染在 DevFrame 聊天列内顶部（absolute，随列宽自适应），展示当前会话最近一条
 * 用户提问；内容超 2 行时默认折叠（line-clamp）并给出「展开/收起」；新提问到达
 * 即更新并复位折叠；无提问不渲染。数据源为 askFeed 单例（官方 sessions 管线，
 * 缺失时快照恒空 → 浮层自然隐藏）。样式在 DevFrame FRAME_CSS（.dskDevAskFloat*）。
 */
import React from 'react';
export declare function AskFloat(): React.JSX.Element | null;
