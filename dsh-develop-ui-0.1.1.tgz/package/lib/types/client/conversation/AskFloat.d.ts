/**
 * client 半：R9 当前提问浮层（C7-1，v2 滚动跟随）。
 * 渲染在 DevFrame 聊天列内顶部（absolute，随列宽自适应），展示**可视区第一行所属
 * 的用户提问**：监听聊天列捕获阶段 scroll（scroll 不冒泡，捕获可及后代滚动），
 * 以浮层底边为可视区上沿，二分找第一可见聊天行（[data-chat-flow-key]，key 与会话
 * 节点一致），该行或其上方最近的提问行即为所求；第一行在所有提问之前 → 显示第一条
 * 提问；无行信息（初始/底部跟随）→ 显示最新提问。内容超 2 行默认折叠（line-clamp）
 * 并给出「展开/收起」；展示文本变化即复位折叠；无提问不渲染。数据源为 askFeed 单例
 * （官方 sessions 管线，缺失时快照恒空 → 浮层自然隐藏）。样式在 DevFrame FRAME_CSS
 * （.dskDevAskFloat*）。
 */
import React from 'react';
export declare function AskFloat(): React.JSX.Element | null;
