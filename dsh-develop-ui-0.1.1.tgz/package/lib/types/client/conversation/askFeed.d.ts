/**
 * client 半：聊天区增强数据管线（C7，无 React 依赖，可独立打包测试）。
 *
 *  - extractUserQuestions：会话快照 chat.nodes → 用户提问队列（升序、连续去重）。
 *    节点形状见 C7-0 探针：{ kind, visibility, data: { kind, seq, content } }，
 *    kind ∈ 'user' | 'steering'；全部访问做 typeof 守卫，结构漂移降级为空数组。
 *  - createAskFeed：ctx.sessions（SessionRuntime）→ list.current → manager.sessions
 *    → Session.subscribe/getSnapshot 的订阅链；快照引用稳定（useSyncExternalStore
 *    契约）；任一环节缺失静默降级为空队列 + 一次性诊断。
 *  - recallMove：↑↓ 历史回显纯状态机（暂存草稿/遍历/恢复/越界），DOM 与 composer
 *    交互在 HistoryRecall.tsx，此处保持纯净可测。
 */
/** askFeed 对外快照（引用稳定：内容不变时返回同一对象）。 */
export interface AskFeedSnapshot {
    /** 当前会话 id（无选定为 undefined） */
    sessionId?: string;
    /** 当前会话用户提问队列（时间升序、连续去重） */
    questions: string[];
}
/**
 * 从会话快照 chat 提取用户提问队列。
 * @param chat 会话快照的 chat 字段（未知形状，逐项守卫）
 * @returns 用户提问文本数组（seq 升序、连续重复去一）；结构不符时返回 []
 */
export declare function extractUserQuestions(chat: unknown): string[];
interface StoreLike {
    subscribe: (fn: () => void) => () => void;
    getSnapshot: () => unknown;
}
/** SessionRuntime 最小面（官方服务，全部可选以便降级） */
export interface SessionsLike {
    list?: StoreLike;
    manager?: {
        sessions?: Map<string, StoreLike>;
    };
}
export interface AskFeed {
    /** 绑定 ctx.sessions 服务（apply 时调用一次；重复调用先解绑旧链） */
    bindSessions: (sessions: SessionsLike | undefined) => void;
    /** useSyncExternalStore 订阅 */
    subscribe: (fn: () => void) => () => void;
    /** 当前快照（引用稳定） */
    getSnapshot: () => AskFeedSnapshot;
}
/**
 * 创建聊天区提问订阅管线。
 * @returns AskFeed 实例；未绑定或服务缺失时快照恒为 EMPTY_FEED
 */
export declare function createAskFeed(): AskFeed;
/** 回显状态：active=回显中；index 指向历史队列；stash 为进入回显前暂存的草稿。 */
export interface RecallState {
    active: boolean;
    index: number;
    stash: string;
}
export declare const RECALL_IDLE: RecallState;
/** 模块级单例：apply 时 bindSessions；AskFloat（R9）与 HistoryRecall（R10）共用。 */
export declare const askFeed: AskFeed;
export interface RecallResult {
    state: RecallState;
    /** 需写入 composer 的草稿；null = 不接管（放行官方默认行为） */
    draft: string | null;
}
/**
 * ↑↓ 回显转移（纯函数）。
 * @param state 当前回显状态
 * @param dir -1=↑（更早）/ 1=↓（更新）
 * @param questions 历史提问队列（升序）
 * @param draft 当前 composer 草稿（首次回显时暂存）
 * @returns 新状态与应写入的草稿；draft=null 表示本次按键不接管
 */
export declare function recallMove(state: RecallState, dir: -1 | 1, questions: readonly string[], draft: string): RecallResult;
export {};
