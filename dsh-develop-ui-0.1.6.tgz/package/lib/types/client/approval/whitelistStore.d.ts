/** 全局单例：白名单增删查、订阅、前缀匹配。 */
export declare const whitelistStore: import("./cmdWhitelist").WhitelistStore;
