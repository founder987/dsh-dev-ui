/** 管理浮层 props。 */
export interface WhitelistManagerProps {
    /** 是否显示浮层 */
    open: boolean;
    /** 关闭回调（⚙ 按钮 / 遮罩 / Esc） */
    onClose: () => void;
}
/**
 * 白名单管理浮层。
 * @param props - WhitelistManagerProps
 * @returns 浮层元素（open=false 时返回 null）
 */
export declare function WhitelistManager(props: WhitelistManagerProps): React.JSX.Element | null;
