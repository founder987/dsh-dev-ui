import type { PendingWait } from '@deepseek-ai/dsh-client-runtime/client';
import './approvalCss';
/** 审批面板 props。 */
export interface ApprovalPanelProps {
    /** approval carrier */
    wait: PendingWait<'approval'>;
    /** 命令全文（等宽展示） */
    command: string;
    /** 命令 normalizeTokens 结果（粒度候选生成源） */
    tokens: string[];
    /** 会话词条（可选，缺失用默认文案） */
    t?: (key: string, params?: Record<string, unknown>) => string;
}
/**
 * 三键审批面板。
 * @param props - ApprovalPanelProps
 * @returns 审批面板元素
 */
export declare function ApprovalPanel(props: ApprovalPanelProps): React.JSX.Element;
