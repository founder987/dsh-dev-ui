import type { ConversationSnapshot, PendingWait } from '@deepseek-ai/dsh-client-runtime/client';
import type { ComposerChainProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
/** 本条目组件 props：chain currency + selector 收窄的 matched + 框架标准 kit。 */
export interface WhitelistEntryProps extends ComposerChainProps {
    /** selector 返回值（shell 命令类 approval carrier） */
    matched: PendingWait<'approval'>;
    /** 会话快照选择器（框架标准 kit，官方 ApprovalPanel 同款用法） */
    useSession: <T>(selector: (snapshot: ConversationSnapshot) => T) => T;
    /** 会话词条（可选，缺失用默认文案） */
    t?: (key: string, params?: Record<string, unknown>) => string;
}
/**
 * chain 条目选择器：命中 shell 命令类 approval；其余交官方条目。
 * @param props - composer chain currency（owner props，纯函数只读它）
 * @returns approval carrier（接管）或 null（交下一条目）
 */
export declare function selectShellApproval(props: ComposerChainProps): PendingWait<'approval'> | null;
/**
 * chain 条目组件：白名单命中自动代答 + 隐藏；未命中渲染三键审批面板。
 * @param props - WhitelistEntryProps
 * @returns 空（自动放行中）或审批面板
 */
export declare function WhitelistEntry(props: WhitelistEntryProps): React.JSX.Element | null;
