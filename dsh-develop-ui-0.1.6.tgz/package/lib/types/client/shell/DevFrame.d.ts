/**
 /**
 * client 半：方案 C 落地版 —— 布局提供者接管（官方 ui-layout 在本 bundle patch 内禁用）。
 * 布局（参考 demo）：sidebar(官方侧栏) | 文件树 | 文件内容 | main(官方对话/全局面板) | rightbar(官方右侧栏)。
 *
 * 与官方契约的对应（@deepseek-ai/dsh-client-ui-layout 0.1.5-rc.2 源码）：
 * - root 槽子声明对齐官方 AppFrame：sidebar(single/root) / main(keyed/root) /
 *   rightbar(single/root) / shell.overlay(list/root)；官方 occupant 渲染在本框架的列里
 *   → 工作区/对话/右侧栏/tool details 功能全保留；
 * - ctx.layout 服务由 index.ts 提供（官方 LayoutController 等价面：selectPanel /
 *   beginNavigation / toggleSidebar / openRightbar / closeRightbar / dispose），
 *   store 实例由本插件创建并交给 root 注册（官方同款接线，不依赖 inject 钩子）；
 * - panelInfo 钩子经 ctx.slots.provideRoot 提供（官方 ui-layout 同款）——
 *   main 槽 entryKey = activePanelId ?? 'conversation'；
 * - 主题 token 呈现由 index.ts 接替（官方 ThemePresenter 等价物）；
 * - 右侧栏轨道（track）由 occupant 经 ctx.layout.openRightbar 声明：无轨道时列宽 0，
 *   occupant 自锚右缘悬浮；sidebar 折叠为 56px rail；1024px 断点自动折叠 +
 *   narrowExpanded 覆盖；让渡链保 center >= 640。
 */
import React from 'react';
export interface DevLayoutState {
    /** 官方面板选择态：null = 会话主面板，字符串 = 全局面板 id（root 槽 main 的 entryKey） */
    panelInfo: {
        activePanelId: string | null;
    };
    /** 官方框架测量与呈现态（与 rc.2 官方 stores.ts 同形） */
    layoutInfo: {
        sidebar: number;
        viewportWidth: number;
        narrowExpanded: boolean;
        rightbar: number | null;
        rightbarShown: boolean;
        rightbarTrack: boolean;
        rightbarFullscreen: boolean;
        rightbarInstant: boolean;
    };
    tree: number;
    editor: number;
    /** 聊天区展开（C8：false = center 列 0 宽保挂载，会话状态保留；会话内保持不持久化） */
    chat: boolean;
}
/** store 实例的绑定动作面（官方 LayoutController 消费 + 本框架列宽动作） */
export interface DevLayoutActions {
    selectPanel: (panelId: string | null) => void;
    retainMainPanels: (panelIds: string[]) => void;
    setSidebar: (px: number) => void;
    toggleSidebar: () => void;
    setViewportWidth: (width: number) => void;
    setRightbar: (px: number) => void;
    openRightbar: (track: boolean, fullscreen: boolean) => void;
    closeRightbar: () => void;
    setTree: (px: number) => void;
    setEditor: (px: number) => void;
    toggleChat: () => void;
}
/** 注册进 root 槽的 store 席位：handle + 固定实例（官方 ui-layout 同款接线） */
export interface DevLayoutSeat {
    create: () => {
        actions: DevLayoutActions;
        getSnapshot: () => DevLayoutState;
        subscribe: (listener: () => void) => () => void;
    };
}
export declare function createDevLayoutStore(): unknown;
interface SessionListStateLike {
    current?: string;
    byId?: Record<string, {
        blank?: boolean;
        cwd?: string;
    }>;
}
/** root 入口框架 props 面的最小契约（框架保证提供；此处结构化声明） */
interface DevFrameProps {
    useStore: <T>(selector: (state: DevLayoutState) => T) => T;
    useSessions: <T>(selector: (state: SessionListStateLike) => T) => T;
    useWorkspaces: <T>(selector: (state: unknown) => T) => T;
    /** 本插件经 ctx.slots.provideRoot 提供的 panelInfo 钩子（main 槽 entryKey 来源） */
    usePanelInfo: <T>(selector: (info: {
        activePanelId: string | null;
    }) => T) => T;
    actions: DevLayoutActions;
    renderSlot: (name: string, owner?: Record<string, unknown>, options?: {
        entryKey?: string;
    }) => React.ReactNode;
}
/** 五列开发框架（root 槽 occupant；官方 sidebar/main/rightbar/shell.overlay 照常渲染） */
export declare function DevFrame({ useStore, useSessions, useWorkspaces, usePanelInfo, actions, renderSlot }: DevFrameProps): React.JSX.Element;
export {};
