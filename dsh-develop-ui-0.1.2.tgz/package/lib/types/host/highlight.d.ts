/** 从文件路径/名称推断 shiki lang */
export declare function detectLanguage(filename: string): string;
/** 渲染代码为高亮 HTML（shiki github-dark 主题，内联样式） */
export declare function highlightCode(source: string, lang: string): Promise<string>;
/** 按文件名推断 lang 并渲染 */
export declare function highlightFile(source: string, filename: string): Promise<string>;
