/**
 * host 半：文件系统操作（纯函数，基于 ctx.fs / @deepseek-ai/dsh-fs）。
 * 由 webServer 路由调用；所有操作自动继承 DSH 沙箱策略（开发规范第 6 节）。
 * 路径边界：resolve 规范化 + 大文件拦截 + 版本守卫写入。
 */
import { type FileSystem } from '@deepseek-ai/dsh-fs';
import type { FsEntry, FsReadImageResult, FsStatResult, FsReadTextResult, FsWriteTextResult } from '../shared/rpc';
/**
 * 列出目录条目：过滤隐藏目录（.git/node_modules/.dsh）与垃圾文件（.DS_Store），
 * 保留用户可见的隐藏文件（.gitignore 等）；目录优先排序由 client 侧处理。
 */
export declare function listDir(fs: FileSystem, path: string): Promise<FsEntry[]>;
/** stat：版本（写回守卫）、类型、大小 */
export declare function stat(fs: FileSystem, path: string): Promise<FsStatResult>;
/** 读取文本：先 stat 拦截超限文件（>1MB），返回内容与版本 */
export declare function readText(fs: FileSystem, path: string): Promise<FsReadTextResult>;
/**
 * 写入文本：版本守卫（replaceIfVersion），版本不匹配抛 FS_STALE_VERSION。
 * sandboxRoot（可选）：本次调用的 workspace-write 根（文件夹白名单）——目标在其下即放行，
 * 无需会话切「完全访问」；由 client 仅在用户已信任的目录上传递。
 */
export declare function writeText(fs: FileSystem, path: string, content: string, expectedVersion: string, sandboxRoot?: string): Promise<FsWriteTextResult>;
/** 从文件路径推断图片 MIME（非图片返回 undefined） */
export declare function imageMimeOf(path: string): string | undefined;
/**
 * 读取图片为 dataUrl（预览用）：readBytes 受 MAX_IMAGE_BYTES 限制（FS_TOO_LARGE）。
 */
export declare function readImage(fs: FileSystem, path: string): Promise<FsReadImageResult>;
