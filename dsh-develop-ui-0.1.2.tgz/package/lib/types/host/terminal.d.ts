import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { TermCreateArgs, TermCreateResult, TermReadResult, TermShellInfo } from '../shared/rpc';
/** 终端服务错误：code 用 TERM_* UPPER_SNAKE（路由层映射 HTTP 状态码） */
export declare class TermError extends Error {
    readonly code: string;
    constructor(message: string, code: string);
}
/** PTY 句柄抽象（与 node-pty IPty 的所需子集结构兼容） */
export interface PtyHandle {
    write(data: string): void;
    resize(cols: number, rows: number): void;
    kill(): void;
    onData(listener: (data: string) => void): void;
    onExit(listener: (info: {
        exitCode: number;
    }) => void): void;
}
/** PTY 工厂签名（生产 = node-pty.spawn，测试 = fake） */
export type PtyFactory = (file: string, args: string[], options: {
    cwd: string;
    cols: number;
    rows: number;
    env: Record<string, string>;
}) => PtyHandle;
/** shell 白名单项：candidates 按优先级排列，取第一个存在的路径 */
export interface ShellSpec {
    id: string;
    title: string;
    candidates: string[];
}
/**
 * shell 白名单（仅 Windows 常见安装路径；wt 是终端模拟器应用，无法嵌入，故不在列）。
 * 安全约束：client 只能传 id，可执行路径由本表硬编码解析，不接受任意路径。
 */
export declare const SHELL_SPECS: ShellSpec[];
/** 服务依赖（全部可注入，测试用 fake） */
export interface TerminalServiceDeps {
    fs: FileSystem;
    ptyFactory: PtyFactory;
    /** 文件存在性探测（默认 existsSync） */
    exists?: (path: string) => boolean;
    /** 输出缓冲字符上限（默认 512KB，超出丢弃最旧） */
    maxBufferChars?: number;
    /** 并发会话上限（默认 16） */
    maxSessions?: number;
}
/** 终端 PTY 会话服务：create/input/resize/read(长轮询)/kill */
export declare class TerminalService {
    private readonly fs;
    private readonly ptyFactory;
    private readonly exists;
    private readonly maxBufferChars;
    private readonly maxSessions;
    private readonly sessions;
    constructor(deps: TerminalServiceDeps);
    /** 解析 shell 的可执行路径：取第一个存在的候选；无 → undefined */
    private resolveExecutable;
    /** 可用 shell 列表（available=false 表示未安装，client 侧禁用该项） */
    listShells(): TermShellInfo[];
    /** 创建会话：白名单校验 → cwd 校验 → spawn → 会话登记 */
    create(args: TermCreateArgs): Promise<TermCreateResult>;
    /** 取会话，不存在 → TERM_SESSION_NOT_FOUND */
    private requireSession;
    /** 键盘输入写入 PTY */
    input(id: string, data: string): void;
    /** 调整终端尺寸（钳制后转发 PTY） */
    resize(id: string, cols: number, rows: number): void;
    /**
     * 长轮询读取：有 cursor 之后的新数据立即返回；否则 hold 至数据到达/进程退出/超时。
     * holdMs 默认 15s（探针结论：桌面端 fetch 经 IPC 桥接，长轮询为已验证通道）。
     */
    read(id: string, after: number, holdMs?: number): Promise<TermReadResult>;
    /** 销毁会话：kill PTY、唤醒挂起 read（exited=true）、移出会话表 */
    kill(id: string): void;
    /** 追加输出到有界缓冲，超出上限丢弃最旧块，并唤醒挂起 read */
    private pushData;
    /** 等待会话变化（新数据/退出/销毁），最长 ms 毫秒 */
    private waitForChange;
    /** 唤醒全部挂起 read */
    private notify;
}
