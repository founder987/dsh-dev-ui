/**
 * host 半：HTTP 工具函数（webServer 路由用）。
 * 参照 dsh-community-market 的 host/routes.js 模式（sendJson/readJson/本机校验）。
 */
/** 发送 JSON 响应（Node res） */
export declare function sendJson(res: {
    statusCode: number;
    setHeader: (k: string, v: string) => void;
    end: (b: string) => void;
}, status: number, value: unknown): void;
/** 读取 JSON 请求体 */
export declare function readJson(req: NodeJS.ReadableStream): Promise<unknown>;
/**
 * 本机请求校验：请求必须来自 DSH web 服务自身端口（防跨站调用）。
 * 参照 market 的 requestAllowed 语义（HTTP 时代仍保留 host 校验）。
 */
export declare function isLocalRequest(req: {
    headers: Record<string, string | string[] | undefined>;
}, expectedPort: number): boolean;
