/** 纯函数：markdown → HTML（html 转义关闭、链接自动识别、换行保留） */
export declare function renderMarkdownToHtml(source: string): string;
