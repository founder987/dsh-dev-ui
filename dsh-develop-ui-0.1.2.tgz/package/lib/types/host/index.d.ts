/**
 * dsh-develop-ui host 半入口。
 * 经 ctx.webServer 注册 HTTP 路由（/api/dsh-develop-ui/*），client 半 fetch 调用
 * （参照 dsh-community-market 的第三方插件模式）。
 * 所有路由带本机端口校验（isLocalRequest），写操作为 POST + 版本守卫。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare function apply(ctx: Context): void;
