/**
 * client 半：侧栏底部"文件树"开关按钮（sidebar.footer.action list 槽）。
 * 变更 C2：📁 emoji → primitives 正式文件夹图标（IconFolderOpen16/Close16）；
 * 注册 order 5 < 插件市场 order 10 → 恒在插件市场按钮上方/左侧。
 */
import React from 'react';
export declare function FileTreeButton(): React.JSX.Element;
