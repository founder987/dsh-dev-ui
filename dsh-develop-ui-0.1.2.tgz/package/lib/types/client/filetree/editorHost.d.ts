/**
 * client 半：monaco 编辑器适配层（C6，替换「透明 textarea 叠 shiki 层」自制编辑器）。
 * - 动态 import monaco：2.6MB 内核首次打开文件时才初始化，不拖慢插件启动；
 * - 单 editor 实例 + 每 tab 一个 model（setModel 切换，保留各 tab undo 栈与视图状态）；
 * - 语言服务 worker 未验证可用：MonacoEnvironment dummy stub，相关特性静默退化，
 *   编辑 / monarch 高亮 / 查找替换 / 多光标 / 括号匹配均在主线程。
 * 选型结论与打包清单见 docs/开发记录/C6-0-编辑器内核探针.md。
 */
import type * as monacoNs from 'monaco-editor';
/** monaco 命名空间类型（editor.api 与顶层包同形） */
export type Monaco = typeof monacoNs;
/**
 * 加载 monaco 内核（缓存 Promise，仅首次真正加载）。
 * 打包清单对齐探针：editor.api + codicon 字体样式 + 18 语言 monarch +
 * 查找替换 / 多光标 / 括号匹配 contrib。JSON 无 monarch（worker 版），plaintext 兜底。
 */
export declare function loadMonaco(): Promise<Monaco>;
/** 扩展名 → monaco 语言 id（未覆盖的扩展名 plaintext 兜底） */
export declare function languageOf(path: string): string;
/** 编辑器事件回调（宿主组件桥接到 fileStore） */
export interface EditorCallbacks {
    /** 用户编辑导致的内容变化（外部 setContent 不触发） */
    onChange(content: string): void;
    /** 选区变化（'' = 无选区） */
    onSelectionChange(snippet: string): void;
    /** Ctrl+S（monaco 命令绑定；与 window keydown 双通道，saveFile 有 saving 重入防护） */
    onSaveShortcut(): void;
}
/** 编辑器句柄：宿主组件的 imperative 桥 */
export interface EditorHandle {
    /**
     * 切换到某路径的 model（不存在则以 content 创建）；保留各 tab undo 栈与视图状态。
     * @param openPaths 当前打开的路径集合，用于回收已关闭 tab 的 model
     */
    setFile(path: string, content: string, openPaths: readonly string[]): void;
    /** 外部内容变更（reload/版本回退）：不触发 onChange 回写（echo 防护） */
    setContent(content: string): void;
    focus(): void;
    dispose(): void;
}
/** 在容器中创建 monaco 编辑器实例（dsk-dark 主题，对齐现有编辑区度量） */
export declare function createEditor(monaco: Monaco, container: HTMLElement, callbacks: EditorCallbacks): EditorHandle;
