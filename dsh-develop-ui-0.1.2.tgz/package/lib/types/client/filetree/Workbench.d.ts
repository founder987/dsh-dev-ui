/**
 * client 半：文件工作台（方案 C —— 树列 + 内容列，由 DevFrame 排入五列框架）。
 * WorkbenchTree：路径输入加载目录树 → 文件夹展开 → 点击文件经 fileStore 共享；
 * WorkbenchEditor：md 源码/预览切换 → monaco 编辑器（C6）+ dirty + Ctrl+S 保存（版本守卫）；
 * @文件 引用模式：composer 按钮触发，选文件后点"引用"注入对话。
 * 文件状态见 fileStore.ts；面板开关/@文件 待选见 store.ts。
 */
import React from 'react';
/** 框架全局标准钩子面（GlobalStandardProps 的子集，由 DevFrame 透传） */
export interface WorkbenchHooks {
    useWorkspaces?: <T>(selector: (state: unknown) => T) => T;
    useSessions?: <T>(selector: (state: unknown) => T) => T;
}
/** 树列本体（填满 DevFrame 树列轨道） */
export declare function WorkbenchTree(props: WorkbenchHooks): React.JSX.Element;
/** 内容列本体（填满 DevFrame 内容列轨道；仅在 tabs.length > 0 时挂载） */
export declare function WorkbenchEditor(props: WorkbenchHooks): React.JSX.Element;
