/**
 * client 半：文件树面板共享状态（模块级 store + subscribe，
 * client 半不能 import 状态库，用 useSyncExternalStore 桥接）。
 * 状态：面板开关、@文件 引用待选（pendingRef）、composer 引用注入回调。
 */
type Listener = () => void;
export declare function subscribeStore(listener: Listener): () => void;
/** 兼容别名（原 subscribePanel） */
export declare const subscribePanel: typeof subscribeStore;
export declare function isPanelOpen(): boolean;
export declare function setPanelOpen(value: boolean): void;
/** 是否处于"选文件用于对话引用"模式（由 composer @文件 按钮触发） */
export declare function isPendingRef(): boolean;
export declare function setPendingRef(value: boolean): void;
interface RevealRequest {
    path: string;
    /** 递增序号：同一文件重复定位也要触发（uSES 快照引用变化） */
    seq: number;
}
/** 当前定位请求（内容列→树列） */
export declare function getReveal(): RevealRequest | null;
/** 请求在树中定位文件（同时会打开树列） */
export declare function setReveal(path: string): void;
/** 引用载荷：文件 + 可选片段（片段级引用时携带选中文本） */
export interface FileReference {
    path: string;
    name: string;
    snippet?: string;
}
export declare function setInsertRefFn(fn: ((ref: FileReference) => void) | null): void;
/** composer 引用注入是否可用（FileRefButton 已注册） */
export declare function isInsertRefAvailable(): boolean;
/**
 * 面板"引用此文件/发送片段"动作：把引用交给 composer 注入。
 * @returns 是否调用成功（false = composer 注入未就绪）
 */
export declare function callInsertRef(ref: FileReference): boolean;
export {};
