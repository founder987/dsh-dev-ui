/**
 * client 半：文件内容编辑区（C6 —— monaco 内核，替换「透明 textarea 叠 shiki 层」）。
 * 薄组件：loadMonaco → createEditor；props 变化桥接 EditorHandle（echo 防护在 handle 内）；
 * 事件回调桥接 fileStore（onChange→setContent / 选区→selectedSnippet / Ctrl+S→saveFile）。
 */
import React from 'react';
interface MonacoEditorAreaProps {
    /** 活动文件路径（model 切换键） */
    path: string;
    /** store 内容（外部变更经 echo 防护同步进 model） */
    content: string;
    /** 当前打开的全部路径（回收已关闭 tab 的 model） */
    openPaths: readonly string[];
    onChange(content: string): void;
    onSelection(snippet: string): void;
    onSaveShortcut(): void;
}
/** monaco 编辑区（填满内容列剩余高度；内核未加载时容器占位） */
export declare function MonacoEditorArea(props: MonacoEditorAreaProps): React.JSX.Element;
export {};
