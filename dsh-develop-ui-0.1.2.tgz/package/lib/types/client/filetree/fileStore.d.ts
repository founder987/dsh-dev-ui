/**
 * client 半：文件内容共享状态（模块级 store + subscribe，与 store.ts 同模式；
 * client 半不能 import 状态库，用 useSyncExternalStore 桥接）。
 * 方案 C 布局：树列与内容列分处对话两侧，文件状态从面板组件提升至此共享。
 * 多标签模型（变更 C1）：tabs 有序路径列表 + activePath + 每标签状态 byPath；
 * 支持逐个关闭、全部关闭、关闭左侧/右侧所有。
 * 数据经 fetch 调 host 路由 /api/dsh-develop-ui/*（参照 market 模式）。
 */
type Listener = () => void;
export type FileViewMode = 'source' | 'preview' | 'highlight' | 'image';
/** 单个标签（文件）的状态 */
export interface TabState {
    content: string;
    /** 保存版本守卫（write-text expectedVersion） */
    version: string;
    dirty: boolean;
    isMd: boolean;
    isCode: boolean;
    mdHtml: string;
    codeHtml: string;
    viewMode: FileViewMode;
    saving: boolean;
    /** 保存失败（版本冲突/权限）→ 提供"重新加载"恢复 */
    saveFailed: boolean;
    /** 图片预览 dataUrl（host read-image） */
    imageSrc: string;
    /** 片段级引用：编辑器选中文本 */
    selectedSnippet: string;
}
export interface FileState {
    /** 打开的文件路径（标签顺序） */
    tabs: string[];
    /** 活动标签路径（'' = 无标签） */
    activePath: string;
    /** 每标签状态（按路径） */
    byPath: Record<string, TabState>;
    /** 内容列可见（最小化 = false；列 0 宽保挂载，状态保留） */
    editorOpen: boolean;
    /** 树/内容共享错误条（加载失败、保存失败等） */
    error: string;
    /** 保存授权提示（未信任目录首次被沙箱拒绝；path = 待保存文件） */
    sandboxPrompt: {
        path: string;
        dir: string;
    } | null;
    /** 已信任目录的授权重试中（等待会话权限放开） */
    sandboxRetry: {
        dir: string;
    } | null;
    /** 关闭确认（涉及 dirty 标签时拦截）：paths = 待关闭，dirtyPaths = 其中未保存的 */
    pendingClose: {
        paths: string[];
        dirtyPaths: string[];
    } | null;
}
export declare function subscribeFile(listener: Listener): () => void;
/** uSES getSnapshot：仅 patch 时换新引用，订阅安全 */
export declare function getFileState(): FileState;
export declare function errText(value: unknown): string;
export declare function setError(error: string): void;
/** 编辑器输入：更新活动标签内容并标脏（清空片段选区） */
export declare function setContent(content: string): void;
export declare function setViewMode(viewMode: FileViewMode): void;
export declare function setSelectedSnippet(selectedSnippet: string): void;
/** 更新活动标签代码高亮 HTML（实时高亮防抖后写入） */
export declare function setCodeHtml(codeHtml: string): void;
/** 内容列最小化/展开（列 0 宽保挂载，文件状态保留，点击文件可恢复） */
export declare function setEditorOpen(editorOpen: boolean): void;
/** 切换活动标签（保留各自状态）；授权流程随之取消（重试只作用于原活动标签） */
export declare function activateTab(path: string): void;
/** 请求关闭一批标签：含未保存（dirty）标签时拦截并弹确认（pendingClose），否则直接关闭 */
export declare function requestCloseTabs(paths: string[]): void;
/** 取消关闭确认 */
export declare function cancelPendingClose(): void;
/** 确认关闭：save = 先逐个保存 dirty 标签（保存失败的标签保留）；discard = 丢弃修改直接关闭 */
export declare function confirmPendingClose(mode: 'save' | 'discard'): Promise<void>;
/** 关闭单个标签（dirty 拦截确认）；关闭活动标签时激活右侧邻居（无则左侧）；最后一个关闭 → 内容列隐藏 */
export declare function closeTab(path: string): void;
/** 全部关闭（内容列隐藏；含 dirty 时拦截确认） */
export declare function closeAllTabs(): void;
/** 关闭 path 左侧所有标签（保留 path 及其右侧；含 dirty 时拦截确认） */
export declare function closeTabsLeft(path: string): void;
/** 关闭 path 右侧所有标签（保留 path 及其左侧；含 dirty 时拦截确认） */
export declare function closeTabsRight(path: string): void;
/** 渲染活动标签的 md 预览（按路径参数化） */
export declare function refreshMarkdown(path: string, source: string): Promise<void>;
/** 打开文件：已有标签 → 激活恢复（保留未保存编辑）；否则读取并追加标签 */
export declare function openFile(path: string): Promise<void>;
/**
 * 保存活动标签（版本守卫）；成功后刷新 md 预览 / 代码高亮。
 * @returns 结果信号：'saved' / 'sandbox-denied' / 'failed'（授权重试循环用）
 */
export declare function saveFile(): Promise<'saved' | 'sandbox-denied' | 'failed'>;
/** 信任文件夹并进入授权保存流程（信任持久化；放行仍需会话权限切换为完全访问） */
export declare function trustDir(dir: string): void;
/** 取消授权流程（关闭提示 / 停止自动重试） */
export declare function cancelSandboxApproval(): void;
/** 强制从磁盘重读（标签保留）：用于保存冲突/失败后的"重新加载"恢复 */
export declare function reloadFile(path: string): Promise<void>;
export {};
