/**
 * client 半：composer "@文件" 按钮（conversation.input.left list 槽，additive）。
 * 点击进入"待选文件"模式并打开文件树面板；用户在面板选文件后点"引用"，
 * 经 inputActions.setDraft 把文件引用文本注入 composer 草稿（agent 可感知）。
 * 参照 InputBar 的 inputActions 契约（setDraft(text) 全量替换草稿）。
 * 稳定性：useInput selector 用 useCallback 固定引用（uSES 契约）；注册只依赖
 * setDraft 引用（不随 draft 反复注销）；setDraft 缺失时按钮显示不可用诊断。
 */
import React from 'react';
interface FileRefButtonProps {
    /** conversation.input 槽注入的输入动作（InputBar 契约的子集） */
    inputActions?: {
        setDraft?: (text: string) => void;
    };
    /** 会话输入状态选择器（读当前草稿，selector 需引用稳定） */
    useInput?: (selector: (state: unknown) => unknown) => unknown;
}
export declare function FileRefButton(props: FileRefButtonProps): React.JSX.Element | null;
export {};
