/**
 * client 半：R10 composer ↑↓ 历史回显（C7-2）。
 * conversation.input.left 槽注册的 0 宽保挂载组件：以隐藏 span 为锚定位本实例
 * 所属 composer（[data-composer-seat]），在 document 冒泡阶段拦其 textarea 的
 * ArrowUp/ArrowDown——该时点官方 React onKeyDown（root 容器委托）已执行完毕，
 * 官方输入触发器弹层（/命令、@提及）消费过的按键 defaultPrevented=true 直接放行；
 * 未消费再按交互条件接管：
 *   ↑：草稿为空或光标在首行 → 回显上一条（首次回显暂存当前草稿）
 *   ↓：回显中 → 前进；越过最新 → 恢复暂存草稿并退出回显
 * 历史队列 = askFeed 当前会话用户提问（与 R9 同管线）；新提问到达（含发送成功）
 * 回显态自动复位。写入经 inputActions.setDraft（FileRefButton 已验证契约），
 * 光标 rAF 后置末尾（尽力而为）。setDraft 缺失时不挂监听（静默降级）。
 * 多实例（主会话 + 已寻址 subagent 各自 InputBar）经锚点 seat 归属判断隔离。
 */
import React from 'react';
interface HistoryRecallProps {
    /** conversation.input 槽注入的输入动作（InputBar 契约的子集） */
    inputActions?: {
        setDraft?: (text: string) => void;
    };
    /** 会话输入状态选择器（读当前草稿，selector 需引用稳定） */
    useInput?: (selector: (state: unknown) => unknown) => unknown;
}
export declare function HistoryRecall(props: HistoryRecallProps): React.JSX.Element | null;
export {};
