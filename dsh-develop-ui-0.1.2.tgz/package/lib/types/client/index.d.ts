import { type SessionsLike } from './conversation/askFeed';
type ThemeSnapshot = {
    active: {
        colorScheme: string;
        tokens: Record<string, string>;
    };
};
type ClientCtx = {
    slots: {
        inject: (name: string, register: () => unknown) => () => void;
        register: (options: unknown, component: unknown) => unknown;
    };
    /** cordis 内置：向 ctx 提供服务（插件间通过 inject 声明消费） */
    reflect: {
        provide: (name: string, service: unknown) => () => void;
    };
    /** 官方 ui-theme 提供的主题服务（本插件只读消费） */
    theme: {
        getTheme: () => ThemeSnapshot;
    };
    /** 官方 runtime 提供的会话运行时（C7 提问浮层/历史回显数据源；缺失时降级） */
    sessions?: SessionsLike;
    on: (event: string, handler: (snapshot: ThemeSnapshot) => void) => () => void;
    effect: (disposer: () => void, label?: string) => void;
};
/**
 * client 半声明的 ctx 服务注入（bundle 静态包协议：exports.inject，参照官方
 * dsh-client-ui-workspace 的 `inject: ["slots", ...]`）。apply 访问 ctx.slots /
 * ctx.theme / ctx.on 必须先在此声明，否则报 "cannot get property ... without inject"。
 * 注意：`layout` 由本插件提供，不在此注入。
 */
export declare const inject: string[];
export declare function apply(ctx: ClientCtx): void;
export {};
