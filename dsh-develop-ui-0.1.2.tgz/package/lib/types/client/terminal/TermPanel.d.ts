/**
 * client 半：终端面板组件（C5 v2 + C9 工作区隔离）。
 * 布局：DevFrame 底部行（grid-row 2，grid-column 2/-1；sidebar 列独占全高）；
 * 0 高保挂载（隐藏保会话，对齐列最小化语义）；顶部行手柄拖拽调高（120–480 + 记忆）。
 * C9：store 全量 state 按 props.cwd 投影当前工作区视图（tabs/activeId/creating/
 * createError）；cwd 变化自动切换展示，其他工作区 PTY 会话与 read 循环全保留；
 * 目标工作区无会话 → 空态（cwd 有效可 + 新建，不自动创建）。
 * tab 交互完全镜像文件内容 Tab：悬停 ✕ 右邻居激活、右键/⋯菜单四动作（锚点语义，
 * 复用 C4 .dskDevCtxMenu）、最后 tab 关闭面板自动隐藏、无 dirty 确认。
 * xterm 画布每 tab 一个实例（display:none 保活）；输入 onData → /input；
 * 输出经 termStore.onTermData（host 长轮询）写入。
 */
import React from 'react';
/** 终端面板本体（cwd = 当前工作区路径，由 DevFrame 计算传入；C9：按 cwd 投影工作区视图，
 *  切换工作区只换展示——其他工作区的 PTY 会话与 read 循环全保留） */
export declare function TermPanel(props: {
    cwd?: string;
}): React.JSX.Element;
