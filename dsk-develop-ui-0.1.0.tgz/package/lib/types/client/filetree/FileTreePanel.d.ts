/**
 * client 半：文件树面板（shell.overlay list 槽，左右停靠双列）。
 * 布局（参考 demo）：左列文件树 | 中间宿主对话（透明穿透）| 右列文件内容。
 * 功能：路径输入加载目录树 → 点击文件夹展开 → 点击文件查看内容 →
 * md 源码/预览切换 → 代码高亮 → textarea 编辑 + dirty + Ctrl+S 保存（版本守卫）；
 * @文件 引用模式：composer 按钮触发，选文件后点"引用"注入对话。
 * 数据经 fetch 调 host 路由 /api/dsk-develop-ui/*（参照 market 模式）。
 */
import React from 'react';
/** overlay 槽 standardProps 的子集（useWorkspaces/useSessions 用于自动检测当前工作区） */
interface PanelProps {
    useWorkspaces?: (selector: (state: unknown) => unknown) => unknown;
    useSessions?: (selector: (state: unknown) => unknown) => unknown;
}
/** 导出组件（overlay 槽需要可挂载组件；props 来自槽 standardProps） */
export declare function FileTreePanel(props: PanelProps): React.JSX.Element | null;
export {};
