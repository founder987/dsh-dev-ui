/**
 * client 半：终端面板状态（C5 v2）——镜像 fileStore 多标签模型。
 * tabs[] + activeId + panelOpen；✕ 关闭右邻居激活；右键/⋯菜单四动作以锚点 tab 为准；
 * 最后 tab 关闭 → 面板自动隐藏；终端无 dirty 概念，不做关闭确认。
 * xterm 实例由 TermPanel 持有；本 store 经 onTermData 订阅把 host 长轮询输出推给画布
 * （通道决策见 docs/开发记录/C5-0-终端探针.md）。
 */
import type { TermShellInfo } from '../../shared/rpc';
type Listener = () => void;
/** 终端标签（id = host 会话 id；exited 进程退出后保留展示「已退出」） */
export interface TermTab {
    id: string;
    title: string;
    shellId: string;
    exited: boolean;
}
interface TermState {
    tabs: TermTab[];
    activeId: string | null;
    panelOpen: boolean;
    height: number;
    /** 可用 shell 探测结果（空数组 = 尚未加载） */
    shells: TermShellInfo[];
    lastShell: string;
    creating: boolean;
    /** 创建失败错误（shell 弹层重开后顶部红字展示） */
    createError: string | null;
}
/** 订阅终端面板状态（useSyncExternalStore 契约） */
export declare function subscribeTerm(listener: Listener): () => void;
/** 当前状态快照（不可变引用，patch 时整体更换） */
export declare function getTermState(): TermState;
/** 订阅会话输出；返回取消函数 */
export declare function onTermData(id: string, listener: (data: string) => void): () => void;
/** 拉取可用 shell 列表（幂等；面板打开时调用） */
export declare function ensureShells(): Promise<void>;
/** 默认 shell：上次选择可用 → 上次；否则 cmd；否则第一个可用项 */
export declare function defaultShell(): string | undefined;
/** 新建终端会话：成功 → 追加 tab 并激活 + 启动读取循环；失败 → createError（弹层重开展示） */
export declare function createTerm(shellId: string, cwd: string): Promise<void>;
/**
 * 设置面板显隐；打开时确保 shell 探测完成，且无 tab 时自动创建首个终端
 * （上次 shell 或 cmd，cwd=工作区路径；cwd 缺失则不创建，由 UI 展示提示行）。
 */
export declare function setPanelOpen(open: boolean, cwd?: string): void;
/** 底部栏终端按钮：切换面板显隐 */
export declare function togglePanel(cwd?: string): void;
/** 设置面板高度（钳制 120–480 + localStorage 记忆） */
export declare function setHeight(px: number): void;
/** 键盘输入（xterm onData → host；fire-and-forget） */
export declare function sendInput(id: string, data: string): void;
/** 尺寸同步（xterm fit 后调用；fire-and-forget） */
export declare function sendResize(id: string, cols: number, rows: number): void;
/** 关闭单个会话；关闭活动 tab 时激活右侧邻居（无则左侧）；最后一个关闭 → 面板隐藏 */
export declare function closeTerm(id: string): void;
/** 全部关闭（面板自动隐藏） */
export declare function closeAllTerms(): void;
/** 关闭锚点左侧所有会话（保留锚点及其右侧） */
export declare function closeTermsLeft(id: string): void;
/** 关闭锚点右侧所有会话（保留锚点及其左侧） */
export declare function closeTermsRight(id: string): void;
/** 激活会话 tab */
export declare function activateTerm(id: string): void;
export {};
