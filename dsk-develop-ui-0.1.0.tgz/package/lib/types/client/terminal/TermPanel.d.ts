/**
 * client 半：终端面板组件（C5 v2）。
 * 布局：DevFrame 底部行（grid-row 2，grid-column 2/-1；sidebar 列独占全高）；
 * 0 高保挂载（隐藏保会话，对齐列最小化语义）；顶部行手柄拖拽调高（120–480 + 记忆）。
 * tab 交互完全镜像文件内容 Tab：悬停 ✕ 右邻居激活、右键/⋯菜单四动作（锚点语义，
 * 复用 C4 .dskDevCtxMenu）、最后 tab 关闭面板自动隐藏、无 dirty 确认。
 * xterm 画布每 tab 一个实例（display:none 保活）；输入 onData → /input；
 * 输出经 termStore.onTermData（host 长轮询）写入。
 */
import React from 'react';
/** 终端面板本体（cwd = 当前工作区路径，由 DevFrame 计算传入） */
export declare function TermPanel(props: {
    cwd?: string;
}): React.JSX.Element;
