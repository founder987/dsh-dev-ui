/**
 * client 半：方案 C 落地版 —— 布局提供者接管（官方 ui-layout 在 profile 层禁用）。
 * 布局（参考 demo）：sidebar(官方会话) | 文件树 | conversation(官方对话) | 文件内容 | details(官方工具详情)。
 *
 * 与官方契约的对应（@deepseek-ai/dsh-client-ui-layout rc.7 源码）：
 * - 同名子槽声明（sidebar/conversation/details/shell.overlay）随 root 注册，
 *   官方 occupant 渲染在本框架的列里 → 工作区/对话/工具详情功能全保留；
 * - ctx.layout 服务由 index.ts 提供（LayoutController 等价面），root 条目
 *   inject 钩子把 bound actions 接线进 attachPanels，官方插件（ui-sidebar/
 *   ui-conversation）的面板切换调用不受影响；
 * - 主题 token 呈现由 index.ts 接替（ThemePresenter 等价物）；
 * - details 列 0 宽保持挂载（tool details 状态不丢）；sidebar 折叠为 56px rail；
 *   1024px 断点自动折叠 + narrowExpanded 覆盖；让渡链保 center >= 640。
 * - 主题由 ui-layout 的 ThemePresenter 负责（其 apply 照常运行，不随 root shadow 失效）。
 */
import React from 'react';
export interface DevLayoutState {
    sidebar: number;
    details: number;
    narrow: boolean;
    narrowExpanded: boolean;
    tree: number;
    editor: number;
}
export declare function createDevLayoutStore(): unknown;
interface SessionListStateLike {
    current?: string;
    byId?: Record<string, {
        blank?: boolean;
        cwd?: string;
    }>;
}
/** root 入口四份框架 props 面的最小契约（框架保证提供；此处结构化声明） */
interface DevFrameProps {
    useStore: <T>(selector: (state: DevLayoutState) => T) => T;
    useSessions: <T>(selector: (state: SessionListStateLike) => T) => T;
    useWorkspaces: <T>(selector: (state: unknown) => T) => T;
    actions: {
        setSidebar: (px: number) => void;
        setDetails: (px: number) => void;
        toggleSidebar: () => void;
        setNarrow: (narrow: boolean) => void;
        openDetails: () => void;
        closeDetails: () => void;
        setTree: (px: number) => void;
        setEditor: (px: number) => void;
    };
    renderSlot: (key: string, owner: Record<string, unknown>) => React.ReactNode;
}
/** 五列开发框架（root 槽 occupant；官方 sidebar/conversation/details 照常渲染） */
export declare function DevFrame({ useStore, useSessions, useWorkspaces, actions, renderSlot }: DevFrameProps): React.JSX.Element;
export {};
